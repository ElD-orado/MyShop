import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Cart from "./Pages/Cart";
import Signin from "./users/Signin";
import Signup from "./users/Signup";

const Routeing = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route exact path="/Signup" element={<Signup />} />
        <Route exact path="/Signin" element={<Signin />} />
        <Route exact path="/Cart" element={<Cart />} />
      </Routes>
    </BrowserRouter>
  );
};
export default Routeing;
