export const cateories = [
    {
        id: 1,
        img:"https://st.depositphotos.com/1007995/3516/i/450/depositphotos_35160903-stock-photo-casual-man-looks-at-you.jpg",
        title: "Shirts Style"
    },
    {
        id: 2,
        img:"https://st3.depositphotos.com/9881904/13185/i/450/depositphotos_131852630-stock-photo-couple-sitting-in-jeans-and.jpg",
        title: "Jeans Style"
    },
    {
        id: 3,
        img:"https://st.depositphotos.com/1017986/2614/i/450/depositphotos_26146317-stock-photo-handsome-man-in-green-shirt.jpg",
        title: "T-Shirts Style"
    }
]

export const product = [
    {
        id: 1,
        img:"https://st.depositphotos.com/1007995/3516/i/450/depositphotos_35160903-stock-photo-casual-man-looks-at-you.jpg",
           },
    {
        id: 2,
        img:"https://st3.depositphotos.com/9881904/13185/i/450/depositphotos_131852630-stock-photo-couple-sitting-in-jeans-and.jpg",
      },
    {
        id: 3,
        img:"https://st.depositphotos.com/1017986/2614/i/450/depositphotos_26146317-stock-photo-handsome-man-in-green-shirt.jpg",
        
    },
    {
        id: 1,
        img:"https://st.depositphotos.com/1007995/3516/i/450/depositphotos_35160903-stock-photo-casual-man-looks-at-you.jpg",
           },
    {
        id: 2,
        img:"https://st3.depositphotos.com/9881904/13185/i/450/depositphotos_131852630-stock-photo-couple-sitting-in-jeans-and.jpg",
      },
    {
        id: 3,
        img:"https://st.depositphotos.com/1017986/2614/i/450/depositphotos_26146317-stock-photo-handsome-man-in-green-shirt.jpg",
        
    },
    {
        id: 1,
        img:"https://st.depositphotos.com/1007995/3516/i/450/depositphotos_35160903-stock-photo-casual-man-looks-at-you.jpg",
           },
    {
        id: 2,
        img:"https://st3.depositphotos.com/9881904/13185/i/450/depositphotos_131852630-stock-photo-couple-sitting-in-jeans-and.jpg",
      },
    {
        id: 3,
        img:"https://st.depositphotos.com/1017986/2614/i/450/depositphotos_26146317-stock-photo-handsome-man-in-green-shirt.jpg",
        
    },
    {
        id: 3,
        img:"https://st.depositphotos.com/1017986/2614/i/450/depositphotos_26146317-stock-photo-handsome-man-in-green-shirt.jpg",
        
    }
]