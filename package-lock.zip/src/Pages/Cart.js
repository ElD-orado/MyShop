import React from 'react'

const Cart = () => {
  return (
    <h1>Cart</h1>
  )
}


export  default Cart;