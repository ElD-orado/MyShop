import React from "react";
import Navbar from "../component/Navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "../component/Header";
import Features from "../component/Features";
import "../style.css";
import Categories from "../component/Categories";
import Products from "../component/Products";
import Footer from "../component/Footer";

function Home() {
  return (
    <>
      <Navbar />
      <Header />
      <div className="features-box">
        <Features />
        <Features />
        <Features />
      </div>
      <Categories />
      <Products />
      <Footer />
    </>
  );
}

export default Home;
