import React from "react";
import ReactDOM from "react-dom";
import Routeing from "./Routeing";
import Home from "./Pages/Home";
import Signup from "./users/Signup";
import Signin from "./users/Signin";
import { BrowserRouter, Route, Routes } from "react-router-dom";

ReactDOM.render(
  <>
    <Home />
    {/* <Routeing/> */}
    
  </>,

  document.getElementById("root")
);
