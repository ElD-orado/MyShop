
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from 'react-router-dom';
import { Cart } from '../Pages/Cart';
import Home from '../Pages/Home';

function ColorSchemesExample() {
  return (
    <>
      <Navbar bg="dark" variant="dark">
        <Container>
          <Navbar.Brand to="" >Navbar</Navbar.Brand>
          <Nav className="me-auto">
            <Nav.Link to="/">Home</Nav.Link>
            <Nav.Link to="/shoping">Shoping</Nav.Link>
            <Nav.Link to="/cart" >Cart</Nav.Link>
            <Nav.Link to="/about">About Us</Nav.Link>
          </Nav>
        </Container>
      </Navbar>
      </>
       )}
       export default ColorSchemesExample;