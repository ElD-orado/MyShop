
import React from 'react'
import styled from 'styled-components';
import { cateories } from '../data';
import Categoriesitem from './Categoriesitem';

const Container = styled.div`
     display:flex;
     justify-content: space-between;
`

const Categories = () => {
  return (
    <Container>
      {cateories.map(item=>(
        <Categoriesitem item={item}/>
      ))}

    </Container>
  )
}


export default Categories;