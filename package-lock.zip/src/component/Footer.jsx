import React from "react";
import styled from "styled-components";

const Container = styled.div`
  display: flex;
  justify-content: space-between;
  background-color:#000 ;
  color: white ;
  padding:30px ;
`;
const Left = styled.div`
  flex: 2;
  display:flex ;
  flex-direction:column ;
`;
const Logo = styled.h1`
 font-weight:700;
 font-size:4rem ;
`;
const Desc = styled.p`
  display:flex ;
  font-weight : 600;
 justify-content:center ;
`;
const Center = styled.div`
  flex: 1;
  padding:20px ;


`;
const Title = styled.h3`
 margin-bottom:30px ;

`;
const List = styled.ul`
   margin:0 ;
   padding:0 ;
   display:flex ;
   flex-wrap:wrap ;
`;
const Listitem = styled.li`
   width:50% ;
   margin-bottom:10px ;
`


const Right = styled.div`
  flex:2 ;
  padding:20px ;
`;
const ContactItem = styled.div``


const Footer = () => {
  return (
    <>
      <Container>
        <Left>
          <Logo>GOA</Logo>
          <Desc>
            "Sed ut perspiciatis unde omnis iste natus error sit voluptatem
            accusantium doloremque laudantium, totam rem aperiam, eaque ipsa
            quae ab illo inventore veritatis et quasi architecto beatae vitae
            dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit
            aspernatur aut odit aut fugit, sed quia consequuntur magni dolores
            eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est,
            qui dolorem ipsum quia dolor sit amet,
          </Desc>
        </Left>
        <Center>  
         <Title>Useful Links</Title>
           <List>
            <Listitem>Home</Listitem>
            <Listitem>Cart</Listitem>
            <Listitem>Man Categorie</Listitem>
            <Listitem>Woman Categorie</Listitem>
            <Listitem>Accessories</Listitem>
            <Listitem>My Account</Listitem>
            <Listitem>Wishlist</Listitem>
            <Listitem>Terms</Listitem>
           </List>
        </Center>
        <Right>
            <Title>Contact US</Title>
                <ContactItem>
                    Rampur Maniharan , Saharanpur , U.P. 247451
                </ContactItem>
                <ContactItem>
                   +91 8193910674
                </ContactItem>
                <ContactItem>
                  himanshurohila2000@gmail.com
                </ContactItem>
            
        </Right>
      </Container>
    </>
  );
};

export default Footer;
