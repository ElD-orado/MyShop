import React from "react";
import styled from "styled-components";
import { product } from "../data";

import Product from "./Product";

const Container = styled.div`
  display: flex;
  padding: 10px;
  flex-wrap: wrap;
  justify-content: space-between;
  background-color:black ;
`;

const Products = () => {
  return (
    <Container>
      {product.map((item) => (
        <Product item={item} />
      ))}
    </Container>
  );
};

export default Products;
