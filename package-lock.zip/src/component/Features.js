import React from "react";
import "../style.css"

export default function Features(){
    return(
        <>
           <div className="features-container">
            <div className="main-card">
                <h4 className="p-4">Free Shipping</h4>
                <small className="p-4">On all order over $2000</small>
            </div>
           </div>
        </>
    )
}