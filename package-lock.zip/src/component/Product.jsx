import React from "react";

import styled from "styled-components";

const Container = styled.div`
  margin-top: 5px;
  width: 280px;
  height: 350px;
  display: flex;
  align-items: center;
  justify-content: center;
  
`;
const Image = styled.img`
  width: 100%;
  height: 75%;
`;
// const Info = styled.div``;
// const Icon = styled.div``;

// const FontAwesomeIcon = styled.div``;

const Product = ({ item }) => {
  return (
    <Container>
      <Image src={item.img} />
    </Container>
  );
};

export default Product;
