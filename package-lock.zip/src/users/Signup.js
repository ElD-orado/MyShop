import React from "react";

const Signup = () =>{
    return(
        <h1>Hello Sign Up...</h1>


    )
}
export default Signup;