import React from "react";

const Signin = () =>{
    return(
     
            <h1>Hello Sign in...</h1>
            
         

    )
}
export default Signin;