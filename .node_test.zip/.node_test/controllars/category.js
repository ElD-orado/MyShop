// const category = require("../models/category");
// const { categorySchema } = require("../models/category");


exports.create = (req,res)=>{
    const { categorySchema } = require("../models/category");
 const category = new categorySchema(req.body);
 category.save((err,data)=>{
  if(err){
    return res.json(400).json({
        error: errorHandler(err)
    })
  }
  res.json({data});
 });
}
exports.newCreate=  (req,res)=>{
    const { categorySchema } = require("../models/category");
    
        const category = new categorySchema(req.body);
        category.save((err,data)=>{
         if(err){
           return res.json(405).json({
               error: errorHandler(err)
           })
         }
         res.json({data});
        });
      }
