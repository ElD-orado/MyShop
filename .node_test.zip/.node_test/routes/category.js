const express = require("express");

const router = express.Router();
const { requireSignin, isAuth, isAdmin } = require("../controllars/auth");

const {newCreate,create } = require("../controllars/category");
const { userById } = require("../controllars/user");


router.post( "/category/create", requireSignin, isAuth, isAdmin, create);
router.param("userId", userById);


module.exports = router;
