const Router = require("express");
const express = require("express");
const router = express.Router();
const bodyParser = require("body-parser");
const { check } = require("express-validator/check");
const {
  signup,
  signin,
  signout,
  requireSignin,
} = require("../controllars/auth");

router.post(
  "/signup",
  [
    check("name")
      .isLength({ min: 3 })
      .withMessage(" name must be at least 3 chars long"),
    check("email").isEmail().withMessage("email is required"),
    check("password")
      .isLength({ min: 5 })
      .withMessage(" password must be at least 5 char long"),
  ],
  signup
);

router.post(
  "/signin",
  [
    check("email").isEmail(),
    check("password")
      .isLength({ min: 5 })
      .withMessage(" password field must be required"),
  ],
  signin
);

router.get("/signout", signout);

module.exports = router;
